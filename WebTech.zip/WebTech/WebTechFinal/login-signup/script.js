async function callAPI(url){
    let response = await fetch(url);
    let data = await response.json();
    let msg = await data.message;
    return msg;
  }

async function store(){

    //document.getElementById("error").innerHTML="";

    var name = document.getElementById('name');
    var pw = document.getElementById('pw');
    var lowerCaseLetters = /[a-z]/g;
    var upperCaseLetters = /[A-Z]/g;
    var numbers = /[0-9]/g;

    if(name.value.length == 0){
        alert('Please fill in email');

    }else if(pw.value.length == 0){
        alert('Please fill in password');

    }else if(name.value.length == 0 && pw.value.length == 0){
        alert('Please fill in email and password');

    }else if(pw.value.length <= 8){
        alert('Password should be greater than 8');

    }else if(!pw.value.match(numbers)){
        alert('please add 1 number');

    }else if(!pw.value.match(upperCaseLetters)){
        alert('please add 1 uppercase letter');

    }else if(!pw.value.match(lowerCaseLetters)){
        alert('please add 1 lovercase letter');

    }else{
        const url = 'http://127.0.0.1:3000/registration/?username=' + name.value + '&password=' +  pw.value;
        let response = '';
        response = await fetch(url);
        console.log(response.json());
        // localStorage.setItem('name', name.value);
        // localStorage.setItem('pw', pw.value);
        console.log(response);
        alert('Your account has been created');
        window.location.href = "SignIN.HTML"
    }
}

//checking
async function check1(){
    //document.getElementById("error").innerHTML="";
    //var storedName = localStorage.getItem('name');
    //var storedPw = localStorage.getItem('pw');

    var userName = document.getElementById('userName');
    var userPw = document.getElementById('userPw');
    //var userRemember = document.getElementById("rememberMe");

    let msg = "Invalid";
    const url = 'http://127.0.0.1:3000/login/?username=' + userName.value + '&password=' +  userPw.value;
    msg = await callAPI(url);

    alert(msg);

    if(msg=="Successful login"){
        localStorage.setItem("user", userName.value);
        //window.location.href = "file:///C:/Users/smeet/OneDrive/Desktop/WebTechFinal/get_started.html";
        window.location.href = "../get_started.html";
    }



    // if(userName.value == storedName && userPw.value == storedPw){
    //     alert('You are logged in.');
    // }else{
    //     alert('Error on login');
    // }
}

function check() { // Function which checks if the entered value is matching the Captcha
    if(document.getElementById('CaptchaEnter').value == document.getElementById('randomfield').value ) {
    
        window.open('https://www.google.co.in','_self');
        // Change the page to which the re-direction is to be done.
        // '_self' parameter makes the webpage open in the same tab. If this effect isn't desired, simply remove it.
        
    }
    else {
        alert('Please re-check the captcha'); // The alert message that'll be displayed when the user enters a wrong Captcha
    }
}