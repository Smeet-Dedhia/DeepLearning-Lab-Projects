 <!-- Basic PHP to demonstrate variables use -->
<html>
    <head>
        <title>
            Hello
</title>
</head>
<body>
    <?php
    $name = "Jake";
    echo "Hello, " . $name;
    ?>
    </body>
    </html>
